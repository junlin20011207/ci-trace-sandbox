CI-TRACE R26 - actual Gitee Web PR merge and offline lab-receipt verification

Result: valid=true, VALID_SIGNED_LAB_OBSERVATION_OF_GITEE_WEB_MERGE_NOT_VENDOR_ATTESTATION.

This bundle records the actual merge of Gitee PR !1 in public test repo liljunlin/test.
PR author: junlin1207. Platform merge identity observed through the owner Web session and public merge-commit author: liljunlin. The PR target is the protected disposable branch ci-trace-r26-protected-20261017. The protected branch is at merge commit 12401c28e176fbb0cd3ff920f5bc5936d98ba6fd; its parents are the original baseline c6a87f2f92a4adf7ebf72a0161f915c7a91a781c and developer commit e27bc918ceab6ef0233a2acbef189af67b333a77. Public Git readback confirmed both ancestors and the expected tree. master remained unchanged at c6a87f2f92a4adf7ebf72a0161f915c7a91a781c. The protected flag remained true.

Verify offline from this directory:
python3 verify_release.py --bundle . --trusted-public-sha256 8c648b361866cc1144788f7ff1317420e683a8ba3c819427dc45697877edd45d

The verifier makes no network calls. It checks the separately pinned public-key fingerprint, the SM2-SM3 grant and receipt signatures, artifact SM3, exact repository/branch/object bindings, merge time window, ancestry and unchanged master. merge_evidence.json is bound by SM3 in receipt.json. The real bundle also passed negative checks for altered artifact/evidence/receipt/grant, replaced trust key, and missing receipt; the details are in the evidence folder outside this source bundle.

The signer is an ephemeral LAB key, not a Gitee/vendor signature and not an organizational approval certificate. Both Gitee accounts are controlled by the same user. This demonstrates platform account/permission separation for the Web PR workflow only. It does not demonstrate Git CLI receive-pack push or independent organizational authority. See the report for the earlier real Web denial of direct protected-branch write and all limits.

Dependencies: Python 3.9+, OpenSSL 3 with SM2 and SM3, Python hashlib SM3. crypto_sm.py is copied unchanged from the R23 research archive. Private key, tokens, cookies and browser session data are not included.
