"""Offline verifier for a signed LAB observation of a real Gitee Web merge.

No network calls. The pinned LAB public key is a trust anchor; this is not a
Gitee-signed attestation or an organizational approval certificate. Missing
receipt means pending, never success. R23 crypto_sm.py supplies SM2/SM3.
"""
import argparse
import hashlib
import re
from datetime import datetime
from pathlib import Path

from crypto_sm import canonical, sm3, strict_json, verify

REPO = "liljunlin/test"
TARGET = "refs/heads/ci-trace-r26-protected-20261017"
SOURCE = "refs/heads/ci-trace-r26-dev-control-20261017"
AUTHORITY = "EPHEMERAL_LAB_SIGNER_NOT_ORGANIZATIONAL_APPROVAL"
GATE = "GITEE_NATIVE_PROTECTED_BRANCH_OWNER_PR_MERGE"
BACKEND = "REAL_GITEE_WEB_PR_MERGE_WITH_PUBLIC_GIT_READBACK"
GRANT_FIELDS = {
    "operation_id", "repository", "source_ref", "source_commit", "source_tree",
    "target_ref", "expected_target_base", "artifact_path", "artifact_sm3",
    "developer_login", "required_merger_login", "required_platform_gate",
    "transport_under_test", "business_authority", "issued_at", "expires_at",
}


def timestamp(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.tzinfo is None:
        raise ValueError("timezone required")
    return result


def check(bundle, trusted_sha256):
    """Return a reason; only the explicit VALID_* reason is a final success."""
    try:
        root = Path(bundle)
        public = root / "issuer_public.pem"
        if (not re.fullmatch(r"[0-9a-f]{64}", trusted_sha256)
                or hashlib.sha256(public.read_bytes()).hexdigest() != trusted_sha256):
            return "TRUST_ANCHOR_MISMATCH"
        grant = strict_json((root / "grant.json").read_bytes())
        if not verify(grant, str(public), "grant"):
            return "GRANT_SIGNATURE_INVALID"
        g = grant["body"]["payload"]
        if set(g) != GRANT_FIELDS:
            return "GRANT_SCHEMA_INVALID"
        if (g["repository"] != REPO or g["target_ref"] != TARGET
                or g["source_ref"] != SOURCE or g["artifact_path"] != "README.md"
                or g["developer_login"] != "junlin1207"
                or g["required_merger_login"] != "liljunlin"
                or g["developer_login"] == g["required_merger_login"]
                or g["required_platform_gate"] != GATE
                or g["transport_under_test"] != "GITEE_WEB_UI_ONLY_NOT_GIT_PUSH"
                or g["business_authority"] != AUTHORITY):
            return "UNEXPECTED_SCOPE_OR_AUTHORITY"
        for key in ("source_commit", "source_tree", "expected_target_base"):
            if not re.fullmatch(r"[0-9a-f]{40}", g[key]):
                return "INVALID_GIT_OBJECT_ID"
        if (not re.fullmatch(r"[0-9a-f]{64}", g["artifact_sm3"])
                or sm3((root / "README.control.md").read_bytes()) != g["artifact_sm3"]):
            return "ARTIFACT_DIGEST_MISMATCH"
        issued, expires = timestamp(g["issued_at"]), timestamp(g["expires_at"])
        if expires <= issued:
            return "INVALID_GRANT_TIME_WINDOW"
        if not (root / "receipt.json").exists():
            return "AWAITING_REAL_PLATFORM_MERGE_RECEIPT"
        receipt = strict_json((root / "receipt.json").read_bytes())
        if not verify(receipt, str(public), "receipt"):
            return "RECEIPT_SIGNATURE_INVALID"
        r = receipt["body"]["payload"]
        if set(r) != {"operation_id", "grant_sm3", "evidence_sm3", "backend", "business_authority"}:
            return "RECEIPT_SCHEMA_INVALID"
        if (r["operation_id"] != g["operation_id"]
                or r["grant_sm3"] != sm3(canonical(grant))
                or r["backend"] != BACKEND or r["business_authority"] != AUTHORITY):
            return "RECEIPT_BINDING_MISMATCH"
        evidence = strict_json((root / "merge_evidence.json").read_bytes())
        if sm3(canonical(evidence)) != r["evidence_sm3"]:
            return "EVIDENCE_DIGEST_MISMATCH"
        if set(evidence) != {"kind", "pr", "remote"} or evidence["kind"] != "PUBLIC_GITEE_PR_AND_GIT_READBACK":
            return "EVIDENCE_SCHEMA_INVALID"
        p, remote = evidence["pr"], evidence["remote"]
        if (p["state"] != "merged" or p["merged"] is not True
                or type(p["number"]) is not int or p["number"] < 1
                or p["author_login"] != g["developer_login"]
                or p["merger_login"] != g["required_merger_login"]
                or p["source_commit"] != g["source_commit"]
                or p["target_branch"] != TARGET.removeprefix("refs/heads/")):
            return "PLATFORM_APPROVAL_MISMATCH"
        if (remote["repository"] != REPO or remote["target_ref"] != TARGET
                or remote["commit"] != p["merge_commit"]
                or not re.fullmatch(r"[0-9a-f]{40}", remote["commit"])
                or remote["tree"] != g["source_tree"]
                or remote["source_is_ancestor"] is not True
                or remote["base_is_ancestor"] is not True):
            return "REMOTE_OBJECT_MISMATCH"
        if remote["master_before"] != remote["master_after"] or remote["master_before"] != g["expected_target_base"]:
            return "DEFAULT_BRANCH_INVARIANT_FAILED"
        merged, observed = timestamp(p["merged_at"]), timestamp(remote["observed_at"])
        if not issued <= merged <= expires or observed < merged:
            return "APPROVAL_OUTSIDE_GRANT_WINDOW"
        return "VALID_SIGNED_LAB_OBSERVATION_OF_GITEE_WEB_MERGE_NOT_VENDOR_ATTESTATION"
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return "INVALID_OR_MISSING_DOCUMENT"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", required=True)
    parser.add_argument("--trusted-public-sha256", required=True,
                        help="Use the separately retained fingerprint, not an untrusted bundled replacement")
    args = parser.parse_args()
    reason = check(args.bundle, args.trusted_public_sha256)
    valid = reason.startswith("VALID_")
    print(canonical({"valid": valid, "reason": reason,
                     "scope": "historical Gitee Web merge; LAB signer; no Git-push or vendor-attestation claim"}).decode())
    return 0 if valid else (3 if reason == "AWAITING_REAL_PLATFORM_MERGE_RECEIPT" else 2)


if __name__ == "__main__":
    raise SystemExit(main())
